-- 동네 찜질방 3D · Supabase 설정 (SQL Editor 에 붙여 넣고 Run)

-- 1) 불가마 버티기 기록판
create table if not exists public.records (
  id   text primary key,                          -- 익명 로그인 사용자 ID
  n    text   not null default '손님' check (char_length(n) <= 10),
  hot  real   not null default 0 check (hot  >= 0 and hot  <= 999),
  cold real   not null default 0 check (cold >= 0 and cold <= 999),
  at   bigint not null default 0
);

alter table public.records enable row level security;

-- 누구나 기록판을 볼 수 있어요
drop policy if exists "records read" on public.records;
create policy "records read" on public.records for select using (true);

-- 자기 기록만 쓰고 고칠 수 있어요 (1인 1기록)
drop policy if exists "records insert own" on public.records;
create policy "records insert own" on public.records for insert to authenticated
  with check (id = auth.uid()::text);

drop policy if exists "records update own" on public.records;
create policy "records update own" on public.records for update to authenticated
  using (id = auth.uid()::text) with check (id = auth.uid()::text);

-- 2) 기록판이 실시간으로 바뀌게
alter publication supabase_realtime add table public.records;
