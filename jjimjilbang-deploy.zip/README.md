# 동네 찜질방 3D — 배포 가이드 (Supabase + GitHub Pages)

이 폴더만 있으면 Claude 밖에서도 누구나 접속해서 같이 놀 수 있어요.

| 파일 | 역할 |
|---|---|
| `index.html` | 게임 본체 |
| `config.js` | **내 Supabase 주소와 키를 넣는 곳** (여기만 고치면 돼요) |
| `supabase-adapter.js` | 멀티플레이와 기록판을 Supabase에 연결하는 코드 |
| `supabase.sql` | Supabase에 한 번만 실행할 설정 (기록판 테이블 + 보안 규칙) |

`config.js`를 채우지 않으면 게임은 **혼자 하기 모드**로 정상 실행돼요.

---

## 1단계 · Supabase 프로젝트 만들기 (약 5분)

1. https://supabase.com 에 가입하고 **New project**를 만들어요.
   - Region은 사용자와 가까운 곳(예: Northeast Asia (Seoul))을 고르세요.
   - Database password는 아무거나 정해도 돼요. 이 게임에서는 쓰지 않아요.
2. 왼쪽 메뉴 **SQL Editor** → **New query**를 열어요. `supabase.sql` 내용을 전부 붙여 넣고 **Run**을 눌러요.
   - 처음 실행하면 성공 메시지가 떠요. 실수로 두 번 실행해서 마지막 줄(publication)에서 "이미 추가됨" 오류가 나는 건 괜찮아요.
3. 왼쪽 메뉴 **Authentication** → **Sign In / Providers**에서 **Anonymous sign-ins**(익명 로그인) 항목을 켜요.
   - 회원가입 없이 브라우저마다 고정 ID를 줘서, 기록판에 1인 1기록만 남게 하는 용도예요.
4. **Project Settings** → **API**(또는 **API Keys**)에서 다음 두 가지를 복사해요.
   - **Project URL** (예: `https://abcdxyz.supabase.co`)
   - **anon public** 키, 또는 **publishable** 키(`sb_publishable_...`)
   - ⚠️ `service_role` / `secret` 키는 절대 쓰지 마세요.

## 2단계 · config.js 채우기

```js
window.JJIM_CONFIG = {
  SUPABASE_URL: 'https://abcdxyz.supabase.co',
  SUPABASE_ANON_KEY: '복사한-anon-또는-publishable-키',
  ROOM: 'jjimjilbang-1'
};
```

`ROOM` 이름이 같은 사람끼리 같은 찜질방에서 만나요. 친구들끼리만 놀 방을 따로 만들고 싶으면 이름만 바꿔서 다른 주소로 하나 더 올리면 돼요.

## 3단계 · GitHub Pages에 올리기 (약 5분)

1. GitHub에서 **New repository**를 눌러 저장소를 만들어요. 이름은 예를 들어 `jjimjilbang`, 공개 범위는 **Public**으로 해요.
2. 저장소 화면에서 **Add file → Upload files**를 눌러요. `index.html`, `config.js`, `supabase-adapter.js` 세 파일을 끌어다 놓고 **Commit changes**를 눌러요.
   - `README.md`, `supabase.sql`은 올려도 되고 안 올려도 돼요.
3. 저장소 **Settings → Pages**로 가요. **Source**는 *Deploy from a branch*, **Branch**는 `main` / `/ (root)`로 고르고 **Save**를 눌러요.
4. 1~2분 뒤 같은 화면 위쪽에 주소가 떠요.
   `https://내아이디.github.io/jjimjilbang/`
   이 주소를 친구들에게 보내면 끝이에요.

> 터미널을 쓴다면:
> ```bash
> git init && git add index.html config.js supabase-adapter.js
> git commit -m "동네 찜질방 3D"
> git branch -M main
> git remote add origin https://github.com/내아이디/jjimjilbang.git
> git push -u origin main
> ```

## 4단계 · 확인하기

- 휴대폰과 컴퓨터로 같은 주소를 동시에 열어 보세요. 오른쪽 위에 **"나 포함 2명 접속 중"**이 뜨고, 서로 캐릭터가 보이면 성공이에요.
- 불가마(중·강)에서 버티기를 해 보고, 찜질 구역 벽에 있는 기록판에 내 기록이 남는지 확인해요. Supabase의 **Table Editor → records**에서도 볼 수 있어요.

## 무엇이 어디에 저장되나요?

| 기능 | 방식 |
|---|---|
| 캐릭터 위치, 채팅, 양머리, 손에 든 음식, 계란 깨기 | Supabase Realtime으로 실시간 공유. 저장은 안 해요. |
| 깔아 둔 매트 | 접속 중인 사람끼리만 공유해요. 나가면 사라져요. |
| 불가마 버티기 기록판 | Supabase DB에 **영구 저장**돼요. 1인(브라우저) 1기록이에요. |
| 지갑, 도장 카드 등 내 진행 상황 | 저장 안 함 (새로고침하면 처음부터) |

## 무료 플랜에서 알아 둘 점

Supabase 무료 플랜의 실시간 기능 한도는 **동시 접속 200명, 초당 메시지 100개**예요. 한도를 넘으면 연결이 잠깐 끊겼다가 자동으로 다시 붙어요.
([공식 문서](https://supabase.com/docs/guides/realtime/limits))

- 게임은 움직이는 사람마다 초당 최대 4번만 위치를 보내요. 가만히 있으면 4초에 한 번만 보내요.
- 그래도 **여러 명이 한꺼번에 계속 뛰어다니면** 한도에 닿을 수 있어요. 사람이 많아지면 Pro 플랜(초당 500개)으로 올리거나, 방(`ROOM`)을 여러 개로 나누세요.
- 익명 로그인은 기본적으로 **같은 IP에서 시간당 30번**까지예요. 학교나 PC방처럼 한 와이파이에서 많은 사람이 처음 접속하면 기록판 저장만 안 될 수 있어요. 같이 노는 기능은 영향이 없어요. 한도는 Supabase **Authentication → Rate Limits**에서 바꿀 수 있어요.
- 악용을 막으려면 Supabase가 권장하는 CAPTCHA(Cloudflare Turnstile 등)를 익명 로그인에 붙이는 걸 고려하세요.

## 게임을 수정했을 때

`index.html`을 바꾼 뒤 GitHub 저장소에 같은 이름으로 다시 업로드하면, 1~2분 뒤 자동으로 반영돼요. 접속자는 새로고침만 하면 돼요.
